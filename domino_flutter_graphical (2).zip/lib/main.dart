import 'dart:math';
import 'package:flutter/material.dart';

void main() { runApp(DominoApp()); }

class DominoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dominoes (Graphical)',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomeScreen(),
    );
  }
}

class Tile {
  final int a, b;
  Tile(this.a, this.b);
  bool isDouble() => a == b;
  String toShort() => '${a}|${b}';
}

class DominoEngine {
  List<Tile> stock = [];
  List<List<Tile>> hands = [[], []];
  List<Tile> board = [];
  int currentPlayer = 0;

  DominoEngine() { _init(); }

  void _init() {
    stock.clear(); hands[0].clear(); hands[1].clear(); board.clear();
    for (int i = 0; i <= 6; i++) for (int j = i; j <= 6; j++) stock.add(Tile(i,j));
    stock.shuffle();
    _deal();
    _findStarter();
  }

  void _deal() {
    for (int p = 0; p < 2; p++) for (int k = 0; k < 7; k++) hands[p].add(stock.removeLast());
  }

  void _findStarter() {
    Tile? starter; int starterPlayer = 0;
    for (int p = 0; p < 2; p++) {
      var doubles = hands[p].where((t)=>t.isDouble()).toList();
      if (doubles.isNotEmpty) {
        doubles.sort((x,y)=>y.a.compareTo(x.a));
        if (starter==null || doubles.first.a>starter.a) { starter=doubles.first; starterPlayer=p; }
      }
    }
    if (starter==null) {
      List<Tile> all = [...hands[0], ...hands[1]];
      all.sort((x,y)=> (y.a+y.b).compareTo(x.a+x.b));
      starter = all.first;
      starterPlayer = hands[0].contains(starter)?0:1;
    }
    board.add(starter!);
    hands[starterPlayer].remove(starter);
    currentPlayer = 1 - starterPlayer;
  }

  List<Tile> legalMoves(List<Tile> hand) {
    if (board.isEmpty) return hand;
    int left = board.first.a;
    int right = board.last.b;
    List<Tile> res = [];
    for (var t in hand) if (t.a==left || t.b==left || t.a==right || t.b==right) res.add(t);
    return res;
  }

  bool playTile(int player, Tile tile, {bool toLeft=false}) {
    if (player != currentPlayer) return false;
    var legal = legalMoves(hands[player]);
    if (!legal.contains(tile)) return false;
    int left = board.first.a; int right = board.last.b;

    if (tile.a==left || tile.b==left) {
      if (tile.b==left) board.insert(0, Tile(tile.a, tile.b));
      else board.insert(0, Tile(tile.b, tile.a));
    } else if (tile.a==right || tile.b==right) {
      if (tile.a==right) board.add(Tile(tile.a, tile.b));
      else board.add(Tile(tile.b, tile.a));
    } else return false;

    hands[player].remove(tile);
    currentPlayer = 1 - currentPlayer;
    return true;
  }

  Tile? draw(int player) {
    if (stock.isEmpty) return null;
    var t = stock.removeLast();
    hands[player].add(t);
    return t;
  }

  bool isFinished() => hands.any((h)=>h.isEmpty) || (!_anyCanMove() && stock.isEmpty);
  bool _anyCanMove() => legalMoves(hands[0]).isNotEmpty || legalMoves(hands[1]).isNotEmpty;
  int winner() {
    for (int p=0;p<2;p++) if (hands[p].isEmpty) return p;
    int s0 = hands[0].fold(0,(a,b)=>a+b.a+b.b);
    int s1 = hands[1].fold(0,(a,b)=>a+b.a+b.b);
    return s0 < s1 ? 0 : 1;
  }
}

class SimpleAI {
  Tile? chooseMove(DominoEngine engine, int player) {
    var legal = engine.legalMoves(engine.hands[player]);
    if (legal.isEmpty) return null;
    legal.sort((a,b) {
      int va = a.isDouble()?100:(a.a+a.b);
      int vb = b.isDouble()?100:(b.a+b.b);
      return vb.compareTo(va);
    });
    return legal.first;
  }
}

class HomeScreen extends StatefulWidget { @override _HomeScreenState createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  DominoEngine engine = DominoEngine();
  SimpleAI ai = SimpleAI();
  bool vsAI = true;
  Tile? selectedTile;
  bool placeLeft = true;

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dominoes - رسومية')),
      body: Column(children: [
        _buildTopBar(),
        _buildBoard(),
        Divider(),
        _buildPlayerHand(),
        _buildControls(),
      ]),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Stock: ${engine.stock.length} | الدور: ${engine.currentPlayer==0?"أنت":"الخصم"}'),
        ElevatedButton(onPressed: _newGame, child: Text('لعبة جديدة')),
      ]),
    );
  }

  Widget _buildBoard() {
    return Container(
      height: 180,
      padding: EdgeInsets.all(8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: engine.board.map((t)=>_boardTile(t)).toList()),
      ),
    );
  }

  Widget _boardTile(Tile t) {
    return Container(
      width: 70, height: 120, margin: EdgeInsets.symmetric(horizontal:6),
      decoration: BoxDecoration(color: Colors.white, border: Border.all(), borderRadius: BorderRadius.circular(8)),
      child: Center(child: Text('${t.a}|${t.b}', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold))),
    );
  }

  Widget _playerTile(Tile t) {
    bool isSelected = selectedTile==t;
    return GestureDetector(
      onTap: () {
        if (engine.currentPlayer!=0) return;
        setState(()=> selectedTile = t);
      },
      child: Container(
        width: 70, height: 110, margin: EdgeInsets.all(6),
        decoration: BoxDecoration(color: isSelected?Colors.teal[100]:Colors.white, border: Border.all(), borderRadius: BorderRadius.circular(8)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('${t.a}|${t.b}', style: TextStyle(fontSize:18, fontWeight: FontWeight.bold)),
          if (t.isDouble()) Text('دبل', style: TextStyle(fontSize:12, color: Colors.grey)),
        ]),
      ),
    );
  }

  Widget _buildPlayerHand() {
    return Container(
      height: 150, padding: EdgeInsets.all(8),
      child: Column(children: [
        Text('يدك', style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height:6),
        Expanded(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: engine.hands[0].map((t)=> _playerTile(t)).toList())))
      ]),
    );
  }

  Widget _buildControls() {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        ElevatedButton(onPressed: _playSelected, child: Text('ضع القطعة')),
        ElevatedButton(onPressed: _drawOrPass, child: Text('سحب/تمرير')),
        ElevatedButton(onPressed: ()=> setState(()=> vsAI = !vsAI), child: Text(vsAI? 'إيقاف AI':'تشغيل AI')),
        Row(children: [
          Text('جهة:'),
          SizedBox(width:8),
          ToggleButtons(children: [Text('يسار'), Text('يمين')], isSelected: [placeLeft, !placeLeft], onPressed: (i)=> setState(()=> placeLeft = i==0)),
        ])
      ]),
    );
  }

  void _newGame() => setState(()=> engine = DominoEngine());

  void _playSelected() {
    if (selectedTile==null) return;
    bool ok = engine.playTile(0, selectedTile!);
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حركة غير صالحة')));
      return;
    }
    selectedTile = null;
    setState(() {});
    _afterMove();
  }

  void _drawOrPass() {
    if (engine.currentPlayer!=0) return;
    var drew = engine.draw(0);
    setState(() {});
    if (drew!=null) return;
    engine.currentPlayer = 1;
    _afterMove();
  }

  void _afterMove() async {
    if (engine.isFinished()) { _showResult(); return; }
    if (engine.currentPlayer==1) {
      await Future.delayed(Duration(milliseconds:400));
      if (vsAI) {
        var choice = ai.chooseMove(engine,1);
        if (choice!=null) engine.playTile(1, choice);
        else engine.draw(1);
        setState(() {});
      } else {
        // محلي: انتظار تفاعل اللاعب الثاني (لا أتدخل تلقائياً)
      }
      if (engine.isFinished()) { _showResult(); return; }
    }
  }

  void _showResult() {
    int w = engine.winner();
    showDialog(context: context, builder: (_) => AlertDialog(title: Text('انتهت اللعبة'), content: Text('الفائز: لاعب ${w+1}'), actions: [TextButton(onPressed: (){ Navigator.pop(context); _newGame(); }, child: Text('حسناً'))]));
  }
}
